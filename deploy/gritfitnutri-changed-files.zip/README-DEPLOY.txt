Grit Fit Nutri — changed files (admin logo/banner/icon/poster/USP sizes)
=======================================================================

Upload these paths into your site root on Hostinger (overwrite existing files).

  admin/views/banners.php
  admin/views/header.php
  admin/views/icons.php
  admin/views/posters.php
  admin/views/usps.php
  css/style.css
  includes/cms.php
  includes/header.php

No database migration required. Sizes save into the existing `settings` table
when you use the new "Display Size" / "Logo size" fields in admin.

After upload: hard-refresh the site, open /admin/, check Header and Banners.
