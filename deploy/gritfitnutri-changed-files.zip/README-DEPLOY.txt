Upload all folders to site root. Required: includes/header.php + css/style.css + pages/home.php
