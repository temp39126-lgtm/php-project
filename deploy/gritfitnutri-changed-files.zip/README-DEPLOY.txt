Upload includes/header.php + css/style.css together.
