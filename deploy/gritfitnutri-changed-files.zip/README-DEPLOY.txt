Upload all files to site root. config.php + includes/cms.php required for size save fix.
