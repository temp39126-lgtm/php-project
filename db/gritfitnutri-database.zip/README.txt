Grit Fit Nutri — database export
================================

Contents
--------
- u582313683_gritfitnutri.sql
    Full mysqldump of the live MariaDB database (schema + data).
    Use this to restore onto another MySQL/MariaDB server.

- init.sql
    The repo's idempotent schema + seed (same as db/init.sql).
    Safe to re-run; creates tables if missing and seeds empty lists.

- row_counts.csv / tables.txt
    Snapshot of what was in the dump when it was created.

This dump is the local seed database, not production Hostinger data.
It includes: default admin user, sample category, sample review, and CMS tables.

Restore (MySQL / MariaDB / phpMyAdmin)
--------------------------------------
1. Create the database (skip if it already exists):

     CREATE DATABASE u582313683_gritfitnutri CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

2. Import the dump:

     mysql -u USER -p u582313683_gritfitnutri < u582313683_gritfitnutri.sql

   Or in phpMyAdmin: Import → choose u582313683_gritfitnutri.sql.

Default admin login after restore: admin / admin123
